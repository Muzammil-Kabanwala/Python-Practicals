"""PTMAE: Pure Python Transactional Micro-Banking & Audit Engine.

Run: python main.py
Only built-in Python facilities are used (no imports required).
Account file format: account_id,account_type,balance per line.
"""


# ================================================================
# MODULE 4: Exceptions shared by the banking modules (Unit 4)
# ================================================================
class BaseSystemError(Exception):
    """Parent class for all expected banking failures."""


class CorruptedRecordError(BaseSystemError):
    """A stored record has an invalid structure or value."""


class OutOfBoundsError(BaseSystemError):
    """A number exceeds a permitted boundary."""


class InsufficientBalanceError(BaseSystemError):
    """A payment exceeds the account's permitted spending balance."""


# ================================================================
# MODULE 1: State control and trajectory guards (Unit 1)
# ================================================================
def calculate_compound_interest(principal, annual_rate, years, compounds=1):
    """Calculate compound interest using basic operators and loops only."""
    if principal < 0 or annual_rate < 0 or years < 0 or compounds <= 0:
        raise OutOfBoundsError('Invalid compound-interest input')
    if not isinstance(years, int) or not isinstance(compounds, int):
        raise OutOfBoundsError('Years and compounds must be integers')
    balance = principal
    year = 0
    while year < years:
        period = 0
        while period < compounds:
            balance = balance * (1 + annual_rate / (100 * compounds))
            period += 1
        year += 1
    return balance - principal


def calculate_penalty(amount, percent, overdue_days, daily_flat_fee=0):
    """Compute a percentage penalty plus per-day fee with loop arithmetic."""
    if amount < 0 or percent < 0 or overdue_days < 0 or daily_flat_fee < 0:
        raise OutOfBoundsError('Penalty inputs cannot be negative')
    if not isinstance(overdue_days, int):
        raise OutOfBoundsError('Days must be an integer')
    penalty = amount * percent / 100
    day = 0
    while day < overdue_days:
        penalty += daily_flat_fee
        day += 1
    return penalty


def trajectory_guard(starting_balance, transactions, safety_threshold):
    """Stop before/when the threshold fails or a termination flag occurs.

    Each transaction is (signed_amount, terminate_flag).
    Return (final_balance, visited_count, reason).
    """
    balance = starting_balance
    checked = 0
    for amount, terminated in transactions:
        # Deliberate short-circuit condition (required by FR-1.3).
        if terminated or balance + amount < safety_threshold:
            return balance, checked, ('termination flag' if terminated else 'safety threshold')
        balance += amount
        checked += 1
    return balance, checked, 'completed'


# ================================================================
# MODULE 2: Hand-written parsing and scope mechanics (Unit 2)
# ================================================================
def parse_raw_log_line(line, delimiter=',', quote_char='"'):
    """Parse CSV-like text by character index, including doubled quotes.

    Never uses split(), replace(), csv, or regular expressions.
    Empty fields and trailing delimiters are retained; malformed quotes fail.
    """
    if len(delimiter) != 1 or len(quote_char) != 1 or delimiter == quote_char:
        raise ValueError('Delimiter and quote must be distinct single characters')
    result = []
    chars = []
    index = 0
    quoted = False
    closed = False
    while index < len(line):
        char = line[index]
        if quoted:
            if char == quote_char:
                if index + 1 < len(line) and line[index + 1] == quote_char:
                    chars.append(quote_char)
                    index += 2
                    continue
                quoted = False
                closed = True
            else:
                chars.append(char)
        elif char == delimiter:
            result.append(''.join(chars).strip())
            chars = []
            closed = False
        elif char == quote_char:
            if chars or closed:
                raise CorruptedRecordError('Unexpected quote inside a field')
            quoted = True
        elif closed:
            if char != ' ' and char != '\t':
                raise CorruptedRecordError('Text after a closing quote')
        else:
            chars.append(char)
        index += 1
    if quoted:
        raise CorruptedRecordError('Unclosed quoted field')
    result.append(''.join(chars).strip())
    return result


def create_audit_filter(threshold):
    """Return a closure which counts inspected records using nonlocal."""
    audited = 0

    def audit(transaction):
        """Return whether this amount meets the threshold, counting calls."""
        nonlocal audited
        audited += 1
        audit.count = audited
        return transaction >= threshold

    audit.count = 0
    return audit


def build_position_filters(positions):
    """Create independently bound lambdas for positional field comparisons."""
    filters = []
    for k in range(positions):
        filters.append(lambda row, expected, k=k: len(row) > k and row[k] == expected)
    return filters


# ================================================================
# MODULE 3: Reverse indexing and same-object queue clean (Unit 3)
# ================================================================
def build_reverse_index(raw_db):
    """Invert branch services using nested comprehensions, unique sorted pairs."""
    return {
        service: sorted({(account_id, branch_id)
                         for branch_id, accounts in raw_db.items()
                         for account_id, services in accounts
                         if service in services})
        for service in {tag
                        for accounts in raw_db.values()
                        for account_id, services in accounts
                        for tag in services}
    }


def clean_transaction_queue(data_list):
    """Clean each item, mutating the given outer list in place.

    Tuples become lists, embedded lists sort descending, sets lose even IDs,
    and duplicate primitive entries are deleted by direct index scans.
    """
    index = 0
    while index < len(data_list):
        item = data_list[index]
        if isinstance(item, tuple):
            item = list(item)
            data_list[index] = item
        if isinstance(item, list):
            item.sort(reverse=True)
        elif isinstance(item, set):
            even_ids = {number for number in item
                        if isinstance(number, int) and number % 2 == 0}
            item.difference_update(even_ids)
        # A primitive is a scalar; avoid extra collections for deduplication.
        elif isinstance(item, (int, float, str, bool)):
            earlier = 0
            duplicate = False
            while earlier < index:
                if isinstance(data_list[earlier], (int, float, str, bool)) and data_list[earlier] == item:
                    duplicate = True
                    break
                earlier += 1
            if duplicate:
                del data_list[index]
                continue
        index += 1
    return data_list


# ================================================================
# MODULE 5: Encapsulated accounts and settlement (Unit 5)
# ================================================================
class Account:
    """Base account with name-mangled private balance and class counter."""
    total_accounts = 0

    def __init__(self, account_id, balance):
        """Create an account with validated ID and starting balance."""
        self.set_account_id(account_id)
        self.set_balance(balance)
        Account.total_accounts += 1

    def get_account_id(self):
        """Return account identifier."""
        return self._account_id

    def set_account_id(self, account_id):
        """Validate and set the protected account identifier."""
        if not isinstance(account_id, str) or not account_id.strip():
            raise ValueError('Account ID must be nonempty text')
        self._account_id = account_id.strip()

    def get_balance(self):
        """Return the private balance."""
        return self.__balance

    def set_balance(self, amount):
        """Validate balance; types are numeric, excluding bool."""
        if isinstance(amount, bool) or not isinstance(amount, (int, float)):
            raise TypeError('Balance must be numeric')
        if amount != amount or amount == float('inf') or amount == -float('inf'):
            raise ValueError('Balance must be finite')
        self.__balance = float(amount)

    def process_settlement(self, amount):
        """Subclasses implement spending policies."""
        raise NotImplementedError('Subclass must implement settlement')


class SavingsAccount(Account):
    """Savings account requiring a 1000-unit minimum balance."""

    def __init__(self, account_id, balance):
        """Initialize inherited account details."""
        super().__init__(account_id, balance)

    def process_settlement(self, amount):
        """Deduct amount while retaining the savings minimum."""
        validate_amount(amount)
        if self.get_balance() - amount < 1000:
            raise InsufficientBalanceError('Savings minimum of 1000 would be breached')
        self.set_balance(self.get_balance() - amount)
        return self.get_balance()


class CurrentAccount(Account):
    """Current account with a private overdraft limit."""

    def __init__(self, account_id, balance, overdraft_limit=500):
        """Initialize account and validate overdraft allowance."""
        super().__init__(account_id, balance)
        validate_amount(overdraft_limit)
        self.__overdraft_limit = overdraft_limit

    def process_settlement(self, amount):
        """Allow payments down to minus the overdraft limit."""
        validate_amount(amount)
        remaining = self.get_balance() - amount
        if remaining < -self.__overdraft_limit:
            raise InsufficientBalanceError('Overdraft limit exceeded')
        self.set_balance(remaining)
        return self.get_balance()


class CreditAccount(Account):
    """Credit account storing available credit as its balance."""

    def __init__(self, account_id, balance, credit_limit=5000):
        """Validate starting available credit against the limit."""
        super().__init__(account_id, balance)
        validate_amount(credit_limit)
        self.__credit_limit = credit_limit
        if balance < 0 or balance > credit_limit:
            raise OutOfBoundsError('Starting credit must be between 0 and credit limit')

    def process_settlement(self, amount):
        """Charge 2.5 percent more and deduct against available credit."""
        validate_amount(amount)
        charged = amount + amount * 2.5 / 100
        if charged > self.get_balance() or charged > self.__credit_limit:
            raise OutOfBoundsError('Credit limit / available credit exceeded')
        self.set_balance(self.get_balance() - charged)
        return self.get_balance()


def validate_amount(amount):
    """Require a finite, non-negative, non-boolean numeric amount."""
    if isinstance(amount, bool) or not isinstance(amount, (float, int)):
        raise TypeError('Amount must be numeric')
    if amount < 0 or amount != amount or amount == float('inf'):
        raise OutOfBoundsError('Amount must be finite and non-negative')


def execute_batch_settlement(account_list, transaction_amount):
    """Process each account in isolation and report successful and failed IDs."""
    successful = []
    failed = []
    for account in account_list:
        try:
            ending_balance = account.process_settlement(transaction_amount)
        except (BaseSystemError, TypeError, ValueError) as error:
            failed.append((account.get_account_id(), str(error)))
        else:
            successful.append((account.get_account_id(), ending_balance))
    print('Batch summary:', len(successful), 'succeeded;', len(failed), 'failed')
    return successful, failed


# ================================================================
# MODULE 4: In-place file modification and dual-stream logging
# ================================================================
def validate_account_record(line):
    """Parse a file record and validate ID, type, and numeric balance."""
    fields = parse_raw_log_line(line.rstrip('\r\n'))
    if len(fields) != 3:
        raise CorruptedRecordError('Expected three fields')
    account_id, account_type, balance_text = fields
    if not account_id or account_type not in ('SAVINGS', 'CURRENT', 'CREDIT'):
        raise CorruptedRecordError('Invalid account ID or account type')
    try:
        balance = float(balance_text)
    except ValueError:
        raise CorruptedRecordError('Non-numeric balance')
    if balance != balance or balance in (float('inf'), -float('inf')):
        raise CorruptedRecordError('Non-finite balance')
    return account_id, account_type, balance


def record_line(account_id, account_type, balance):
    """Serialize an account as one newline-terminated plain-text record."""
    return account_id + ',' + account_type + ',' + format(balance, '.2f') + '\n'


def initialize_accounts(filename='accounts.db'):
    """Create the sample database only if it does not yet exist."""
    try:
        with open(filename, 'r', encoding='utf-8'):
            pass
    except FileNotFoundError:
        with open(filename, 'w', encoding='utf-8', newline='') as file:
            file.write('Acc101,SAVINGS,5200.00\n')
            file.write('Acc102,CURRENT,150.00\n')
            file.write('Acc103,CREDIT,4000.00\n')
            file.write('Acc104,SAVINGS,1850.00\n')


def shift_tail(file, start, change, old_end, chunk_size=512):
    """Move the remaining ASCII text in chunks so replacement can vary in size.

    With r+ text streams, offsets are used here only for ASCII files with
    LF newlines; the project record format is explicitly restricted to ASCII.
    """
    if change > 0:
        cursor = old_end
        while cursor > start:
            length = chunk_size if cursor - start > chunk_size else cursor - start
            cursor -= length
            file.seek(cursor)
            content = file.read(length)
            file.seek(cursor + change)
            file.write(content)
    elif change < 0:
        cursor = start
        while cursor < old_end:
            file.seek(cursor)
            content = file.read(chunk_size)
            if not content:
                break
            file.seek(cursor + change)
            file.write(content)
            cursor += len(content)
        file.truncate(old_end + change)


def update_account_record(account_id, new_balance, filename='accounts.db'):
    """Update all matching record values using r+, seek, tell, and truncate.

    Invalid records get one numbered log entry each; successful updates get
    one ledger entry each. Errors in a record do not stop later records.
    The function preserves unaffected lines when a record changes length.
    """
    processed = 0
    rejected = 0
    updated = 0
    try:
        validate_amount(new_balance)
        with open(filename, 'r+', encoding='utf-8', newline='') as file:
            with open('corrupted.log', 'a', encoding='utf-8') as errors:
                with open('ledger.txt', 'a', encoding='utf-8') as ledger:
                    line_number = 0
                    while True:
                        start = file.tell()
                        original = file.readline()
                        if not original:
                            break
                        line_number += 1
                        processed += 1
                        try:
                            # Ensure that text seek offsets and lengths match:
                            # file's storage format is newline LF and ASCII only.
                            if not original.isascii() or ('\r' in original):
                                raise CorruptedRecordError('Expected ASCII / LF text record')
                            stored_id, kind, current = validate_account_record(original)
                            if stored_id != account_id:
                                continue
                            replacement = record_line(stored_id, kind, new_balance)
                            if not original.endswith('\n'):
                                replacement = replacement[:-1]
                            next_record = file.tell()
                            file.seek(0, 2)
                            end = file.tell()
                            difference = len(replacement) - len(original)
                            shift_tail(file, next_record, difference, end)
                            file.seek(start)
                            file.write(replacement)
                            file.flush()
                            file.truncate(end + difference)
                            file.seek(start + len(replacement))
                        except (BaseSystemError, ValueError, TypeError) as exc:
                            rejected += 1
                            errors.write('Line ' + str(line_number) + ': ' + str(exc) + '\n')
                            # Advance past this record if it wasn't changed.
                            file.seek(start + len(original))
                        else:
                            if stored_id == account_id:
                                updated += 1
                                ledger.write(stored_id + ': ' + format(current, '.2f') +
                                             ' -> ' + format(new_balance, '.2f') + '\n')
                    if updated == 0:
                        print('No matching valid account:', account_id)
    except (OSError, BaseSystemError, TypeError, ValueError) as exc:
        print('File transaction error:', exc)
    else:
        print('File transaction complete; updates:', updated)
    finally:
        print('File audit counts - processed:', processed, 'rejected:', rejected)
    return updated, rejected


def show_accounts(filename='accounts.db'):
    """Print valid records, isolating and reporting invalid ones."""
    with open(filename, 'r', encoding='utf-8') as file:
        for number, line in enumerate(file, 1):
            try:
                account_id, kind, balance = validate_account_record(line)
            except CorruptedRecordError as exc:
                print('Line', number, 'corrupted:', exc)
            else:
                print(account_id, '|', kind, '|', format(balance, '.2f'))


# ================================================================
# Demonstrations and text command interface
# ================================================================
def run_demonstration():
    """Exercise every functional area with non-destructive examples."""
    print('\n=== PTMAE REQUIREMENT DEMONSTRATION ===')
    print('Compound interest: 1000, 10%, 2y =', round(calculate_compound_interest(1000, 10, 2), 2))
    print('Compound interest: 2000, 5%, 1y =', round(calculate_compound_interest(2000, 5, 1), 2))
    print('Penalty: ', calculate_penalty(1000, 2, 3, 5))
    print('Trajectory/threshold:', trajectory_guard(1500, [(-100, False), (-500, False)], 1000))
    print('Trajectory/termination:', trajectory_guard(1500, [(-100, False), (-1, True)], 1000))
    for sample in ['Acc1,"card,upi",100', '"A""B",,4', 'x,y,']:
        print('Parsed:', parse_raw_log_line(sample))
    audit_a = create_audit_filter(50)
    audit_b = create_audit_filter(100)
    print('Audit A:', audit_a(90), audit_a(25), 'calls:', audit_a.count)
    print('Audit B:', audit_b(90), 'calls:', audit_b.count)
    for i, position_test in enumerate(build_position_filters(3)):
        print('Position', i, position_test(['A', 'B', 'C'], ['A', 'B', 'C'][i]))
    raw_db = {
        'BRANCH_01': [('Acc101', {'DEPOSIT', 'UPI'}), ('Acc102', {'LOAN', 'UPI'})],
        'BRANCH_02': [('Acc101', {'SAVINGS', 'UPI'}), ('Acc103', {'CARD', 'DEPOSIT'})]
    }
    print('Reverse index:', build_reverse_index(raw_db))
    queue = [(3, 1, 2), [6, 2, 4], {1, 2, 3, 4}, 5, 5, 'x', 'x']
    before = id(queue)
    clean_transaction_queue(queue)
    print('Queue:', queue, 'same object:', id(queue) == before)
    accounts = [SavingsAccount('S1', 1200), CurrentAccount('C1', 20, 200),
                CreditAccount('R1', 500, 1000), SavingsAccount('S2', 1050)]
    print('Name-mangled private balance:', accounts[0]._Account__balance)
    try:
        print(accounts[0].__balance)
    except AttributeError:
        print('Direct .__balance access fails, as expected')
    print('Subclass checks:', all(issubclass(cls, Account)
                                   for cls in (SavingsAccount, CurrentAccount, CreditAccount)))
    print('Exception hierarchy:', all(issubclass(cls, BaseSystemError) for cls in
                                       (CorruptedRecordError, OutOfBoundsError, InsufficientBalanceError)))
    print('Batch results:', execute_batch_settlement(accounts, 100))
    print('Total instantiated accounts:', Account.total_accounts)
    initialize_accounts()
    # Requirement FR-4.x: exercise update, ledger and error logging.
    update_account_record('Acc102', 25.5)
    show_accounts()
    print('=== END DEMONSTRATION ===\n')


def interactive_cli():
    """Read commands with nested while loops until explicit EXIT is entered."""
    initialize_accounts()
    print('PTMAE Banking Engine | HELP for commands | EXIT to quit')
    running = True
    while running:
        command = input('PTMAE> ').strip().upper()
        while True:  # nested loop for each command's processing state
            try:
                if command == 'EXIT':
                    running = False
                    print('Goodbye.')
                elif command == 'HELP':
                    print('HELP | SHOW | UPDATE | INTEREST | PENALTY | DEMO | EXIT')
                elif command == 'SHOW':
                    show_accounts()
                elif command == 'UPDATE':
                    target = input('Account ID: ').strip()
                    amount = float(input('New balance: '))
                    update_account_record(target, amount)
                elif command == 'INTEREST':
                    p = float(input('Principal: '))
                    rate = float(input('Annual rate %: '))
                    years = int(input('Whole years: '))
                    periods = int(input('Compounds per year: '))
                    print('Interest:', calculate_compound_interest(p, rate, years, periods))
                elif command == 'PENALTY':
                    amount = float(input('Base amount: '))
                    percent = float(input('Penalty %: '))
                    days = int(input('Overdue days: '))
                    fee = float(input('Daily flat fee: '))
                    print('Penalty:', calculate_penalty(amount, percent, days, fee))
                elif command == 'DEMO':
                    run_demonstration()
                else:
                    print('Unknown command. Type HELP.')
            except (ValueError, TypeError, BaseSystemError, OSError) as exc:
                print('Command error:', exc)
            break


if __name__ == '__main__':
    try:
        run_demonstration()
        interactive_cli()
    except (EOFError, KeyboardInterrupt):
        print('\nInput ended; goodbye.')
