# PTMAE — Project Documentation

**Project:** Pure Python Transactional Micro-Banking & Audit Engine  
**Specification:** PTMAE-SRS-1.0  
**Course:** Python Programming, Units 1–5  
**Deliverables:** `main.py` and `Documentation.md`

## 1. Project overview

PTMAE is a single-process command-line banking demonstration. It computes interest and penalties, manually parses quoted log records, demonstrates scoped functions, inverts account-service data, cleans transaction queues in place, updates a plain-text account database in `r+` mode, and settles transactions using account subclasses.

It uses only Python built-ins; **no imports, third-party libraries, network service, GUI, or database engine** are required.

## 2. Running the project

1. Place `main.py` in a writable folder.
2. Run `python main.py` (or `python3 main.py`).
3. The program first demonstrates the functional requirements and then opens the `PTMAE>` command prompt.
4. Enter `HELP` to see supported commands. Enter `EXIT` to quit.

The program creates `accounts.db` the first time it runs. It also creates or appends to `ledger.txt` when records are updated, and opens `corrupted.log` to record invalid lines. The demonstration deliberately updates `Acc102` to `25.50` each time it runs; consequently, it changes the working database and appends a ledger entry.

### Commands

| Command | Purpose |
|---|---|
| `HELP` | Show available commands |
| `SHOW` | Display existing account records |
| `UPDATE` | Set an account's balance via in-place record update |
| `INTEREST` | Calculate compound interest |
| `PENALTY` | Calculate percentage plus daily penalty |
| `DEMO` | Re-run all sample demonstrations |
| `EXIT` | Close the program |

## 3. ASCII architecture diagram

```text
+------------------------+
|     main.py entry      |
+-----------+------------+
            |
            v
+------------------------+
| run_demonstration()    |
+-----------+------------+
            |
            v
+------------------------+     +-------------------------+
| interactive_cli()      |---->| Module 1: State Engine  |
| HELP/SHOW/UPDATE/...   |     | loops, arithmetic, guard|
+-----+------+-----------+     +-------------------------+
      |      |
      |      +---------------->+-------------------------+
      |                        | Module 2: Log Parser    |
      |                        | state flags, closures   |
      |                        +-------------------------+
      |                        +-------------------------+
      +----------------------->| Module 3: Data Inversion|
      |                        | comprehension, mutation |
      |                        +-------------------------+
      |                        +-------------------------+
      +----------------------->| Module 4: File Modifier |
      |                        | r+, seek/tell, exceptions|
      |                        +-----------+-------------+
      |                                    |
      |                       +------------+---------------+
      |                       |            |               |
      |                   accounts.db   ledger.txt    corrupted.log
      |
      +----------------------->+-------------------------+
                               | Module 5: Polymorphism  |
                               | Account subclasses      |
                               +-------------------------+
```

### ASCII class hierarchy

```text
                   +---------------------------+
                   |          Account          |
                   |---------------------------|
                   | total_accounts (class)    |
                   | _account_id (protected)   |
                   | __balance (private)       |
                   | getters / setters        |
                   | process_settlement()      |
                   +-------------+-------------+
                                 |
                  +--------------+--------------+
                  |              |              |
                  v              v              v
          +---------------+ +---------------+ +---------------+
          |SavingsAccount | |CurrentAccount | | CreditAccount |
          |min >= 1000    | |private overdraft| |2.5% fee;     |
          |               | |limit          | |credit limit   |
          +---------------+ +---------------+ +---------------+

BaseSystemError (Exception)
  |-- CorruptedRecordError
  |-- OutOfBoundsError
  `-- InsufficientBalanceError
```

## 4. State and scope tracking table

| State / name | Location / scope | Change / lookup | Demonstration |
|---|---|---|---|
| `running` | Local variable in `interactive_cli()` | Set false only by `EXIT` | Nested command loops |
| `balance` | Local variable in `trajectory_guard()` | Updated once per accepted step | Early threshold/flag stopping |
| `audited` | Enclosing scope of `create_audit_filter()` | Mutated through `nonlocal` | Two independent filter counts |
| `k` | Default parameter of each returned lambda | Captured with `k=k` at creation | Index-specific criteria |
| `raw_db` | Local demo data | Read by nested comprehensions | Reverse service-to-account index |
| `data_list` | Function parameter | Outer list mutated, never rebound | Identical `id` before/after |
| `total_accounts` | `Account` class attribute | Incremented for each created instance | Printed total account count |
| `_account_id` | Protected instance attribute | Managed by public setter | `get_account_id()` |
| `__balance` | Private instance attribute | Name-mangled to `_Account__balance` | Mangled read works; direct `.__balance` fails |
| `__overdraft_limit` | Private `CurrentAccount` attribute | Read within overridden settlement | Overdraft rejection |
| `__credit_limit` | Private `CreditAccount` attribute | Read within overridden settlement | Credit limit rejection |
| `processed`, `rejected`, `updated` | Local variables in file-update function | Incremented during record scan | Printed from `finally` |
| Global variables | Module level | No global mutable state is used for closure communication | Complies with closure constraints |

## 5. Functional requirements traceability

| Requirement ID | Implementation | Demonstration / acceptance evidence |
|---|---|---|
| FR-1.1 | `interactive_cli` nested `while` loops | Invalid/valid commands continue; `EXIT` stops |
| FR-1.2 | `calculate_compound_interest`, `calculate_penalty` | Two interest examples and penalty example |
| FR-1.3 | `trajectory_guard` with `or` short-circuiting | Threshold and termination examples |
| FR-2.1–FR-2.1.4 | `parse_raw_log_line` indexed character state machine | Quoted delimiter, doubled quote, empty and trailing fields |
| FR-2.2 | `create_audit_filter` / `nonlocal` | Counts increase independently |
| FR-2.3 | `build_position_filters` / `k=k` | Each lambda tests its own position |
| FR-3.1 | `build_reverse_index` nested set/dict comprehensions | Sorted unique `(account_id, branch_id)` pairs |
| FR-3.2–FR-3.2.4 | `clean_transaction_queue` | Tuple conversion, set difference, descending list sort, in-place primitive deduplication |
| FR-4.1 | Four exception classes | `issubclass` checks; base exception catches all descendants |
| FR-4.2 | `update_account_record`, `shift_tail` | `r+` scanning with `tell`, `seek`, shifted remainder and `truncate` |
| FR-4.3 | `update_account_record` | `try`/`except`/`else`/`finally` and processed/rejected counts |
| FR-4.3.1 | `corrupted.log` | Rejected input logs include line number and reason |
| FR-4.3.2 | `ledger.txt` | Each accepted record update appends an entry |
| FR-4.3.3 | `finally` in `update_account_record` | Counts printed even after an error |
| FR-5.1.1–FR-5.1.3 | `Account` attributes and accessors | Encapsulation and mangling examples |
| FR-5.1.4 | Subclasses / `super().__init__` | Three subclasses are instantiated |
| FR-5.2 | Subclass `process_settlement` overrides | Savings minimum, overdraft, surcharge and available credit |
| FR-5.3 | `execute_batch_settlement` | One rejected account does not prevent later processing |

## 6. Data formats and file-handling details

An account record has the following structure:

```text
Acc101,SAVINGS,5200.00
Acc102,CURRENT,150.00
Acc103,CREDIT,4000.00
```

One record is stored per line. Supported account types are `SAVINGS`, `CURRENT`, and `CREDIT`. A record is invalid if the field count, account ID, type, or balance is invalid. Invalid records remain in the file and are logged instead of aborting the entire scan.

For a matching account, the updater calculates the replacement record's length. When the new record is longer, it shifts later content backward from the end of the file toward the insertion point; when shorter, it shifts later content forward in chunks, then truncates. It writes the updated record at the original location. The updater never loads the whole database into one string for rewriting.

**File format limitation:** The in-place text offset calculations assume ASCII records, LF line endings, and a single-process environment. Non-ASCII or CRLF records are logged as invalid for the update operation. This is an educational plain-text implementation, not a crash-safe or concurrent production banking database. Also, stored credit-account balances represent available credit; settlement is demonstrated on in-memory objects, whereas the file `UPDATE` command explicitly sets balances.

### Ledger and corrupted-record examples

```text
ledger.txt:
Acc102: 150.00 -> 25.50

corrupted.log:
Line 3: Non-numeric balance
```

## 7. Units 1–5 compliance checklist

- [x] Unit 1: nested loops, conditionals, short-circuit `and`/`or`, arithmetic-only financial calculations
- [x] Unit 2: manually indexed string parser, slices, flags, nested functions, `nonlocal`, properly bound lambdas
- [x] Unit 3: dictionary / set / nested comprehensions, sorted unique index, in-place list operations
- [x] Unit 4: `r+`, `tell`, `seek`, `truncate`, chunk shifting, custom exceptions, `try`/`except`/`else`/`finally`, separate logs
- [x] Unit 5: inheritance, private/protected/class attributes, getters/setters, `super()`, polymorphism and failure isolation
- [x] Imports: none (compliant with the allowlist of `random` and `datetime` only)
- [x] No `csv`, `json`, `re`, `math`, `os`, `sys`, `sqlite3` or external packages
- [x] Parser avoids `str.split()` and `str.replace()`
- [x] No `max()`, `min()` or `sum()` used
- [x] No `global` variable used for closure state
- [x] Queue's original top-level list object is preserved
- [x] Files opened with `with` statements
- [x] Documentation contains both required ASCII diagrams and state/scope table

## 8. Suggested manual acceptance checks

1. Parser: confirm `parse_raw_log_line('"x,y",z,')` produces `['x,y', 'z', '']`.
2. Escaping: confirm `parse_raw_log_line('"a""b",c')` produces `['a"b', 'c']`.
3. In-place list: compare `id(data_list)` before and after cleaning.
4. Interest: compare `1000` at `10%` for two annual compounding periods with hand calculation; interest is `210`.
5. Fault isolation: run the mixed account batch and verify one savings failure does not halt the other accounts.
6. In-place update: note the content of neighboring lines before and after changing a balance's digit count.
7. Log errors: insert one malformed ASCII record (e.g. `Broken,SAVINGS,abc`) and confirm one line-numbered rejection is written.
8. UI: enter an unknown command followed by `SHOW` and `EXIT`; the loop should remain usable after the first command.

## 9. Implementation notes

Amounts are represented as Python floating-point numbers to stay within this assignment's allowed syllabus constructs. Real financial software should use exact decimal representation, crash-safe storage, concurrency control, transactional journaling, and strong validation; those are intentionally outside this SRS's educational constraints.
